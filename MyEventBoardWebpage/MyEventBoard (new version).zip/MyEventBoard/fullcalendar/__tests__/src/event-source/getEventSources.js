describe('getEventSources', function() {

  xit('correctly retrieves event sources provided via `events` at initialization', function() {
  })

  xit('correctly retrieves event sources provided via `eventSources` at initialization', function() {
  })

  xit('correctly retrieves event sources provided via `addEventSource` method', function() {
  })

})
