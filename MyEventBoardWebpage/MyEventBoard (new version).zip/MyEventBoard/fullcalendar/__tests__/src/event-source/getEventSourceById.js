describe('getEventSourceById', function() {

  xit('correctly retrieves an event source provided via `events` at initialization', function() {
  })

  xit('correctly retrieves an event source provided via `eventSources` at initialization', function() {
  })

  xit('correctly retrieves an event source provided via `addEventSource` method', function() {
  })

})
