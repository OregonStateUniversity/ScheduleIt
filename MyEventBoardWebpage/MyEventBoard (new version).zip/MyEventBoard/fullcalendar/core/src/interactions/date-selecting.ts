import { Hit } from './hit'

export type dateSelectionJoinTransformer = (hit0: Hit, hit1: Hit) => any
